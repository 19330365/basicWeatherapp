package com.example.betterweather.Model;

class Rain {
}
