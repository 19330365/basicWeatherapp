package com.example.betterweather.Model;

class Clouds
{
    public Clouds() {
    }

    private int all;

    public int getAll() {
        return all;
    }

    public void setAll(int all) {
        this.all = all;
    }
}
