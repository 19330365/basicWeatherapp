package com.example.betterweather.Model;

 public class Wind
{
    public Wind() {
    }

    private double speed;

    public double getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }
}
